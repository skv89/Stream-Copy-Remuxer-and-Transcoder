# PyInstaller 6.16.0 portable launcher source

This archive supplies the third-party launcher source used by Stream Copy Remuxer and Transcoder v1.3.2. It contains no application source or private test data.

The upstream source archive is unchanged. Its SHA-256 is:
53559fe1e041a234f2b4dcc3288ea8bdd57f7cad8a6644e422c27bb407f3edef

## Changes dated 2026-10-15

The single changed C file resolves its temporary directory from the physical EXE location, rejects linked data/temp folders, uses literal private runtime paths, and keeps extraction temporary files beside the EXE. Other upstream sources and the upstream cleanup/access restrictions are unchanged. A dated comment has been added to this source copy; the compiled implementation is otherwise identical.

## Build the Windows x64 windowed launcher

1. Extract pyinstaller-6.16.0.tar.gz.
2. Replace bootloader/src/pyi_utils_win32.c with the supplied modified file, or apply portable-bootloader.patch from the extracted source root.
3. Install Python 3.11 and Microsoft C++ Build Tools with Windows SDK.
4. In the extracted bootloader directory, run:
   python waf configure build_releasew install_releasew --target-arch=64bit

The launcher is written to PyInstaller/bootloader/Windows-64bit-intel/runw.exe. Python 3.11 and Microsoft C++ Build Tools were used for the supplied application. The archive includes the upstream build scripts, headers and bundled zlib sources. No change to the Python application's encoding logic is included here.

## License

PyInstaller is GPL-2.0-or-later with its Bootloader exception; certain files use Apache-2.0 or MIT terms. All upstream license notices remain in the original archive. See COPYING.txt and the upstream documentation at https://pyinstaller.org/en/v6.16.0/license.html.
